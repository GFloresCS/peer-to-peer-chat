package chat;

import chat.subclass.ConnectionLists;
import chat.subclass.Client;
import chat.subclass.Handler;
import chat.subclass.Server;

import java.io.*;
import java.util.*;
import java.net.*;

//ran by doing the following on the command line in Chat.java directory
//javac Chat.java
//java Chat arg0(PortNumber)
public class Chat {

    //public static ArrayList<String> iPAddress = new ArrayList<String>();
    private static int PORT_NUMBER;

    public static void main(String[] args) throws IOException {
        //make sure they input a port number from 1024-49151
        //if they didn't send the port number in the command line then pick a random port from 5000-6000
        //or if they made an error just assign a random port
        int initPort;
        if (args.length > 0) {
            try {
                initPort = Integer.parseInt(args[0]);
                if((1023 < initPort) && (49152 > initPort)) {
                    PORT_NUMBER = initPort;
                }
                else {
                    System.out.println("The port number should be between 1024 and 49151.");
                    System.out.println("A random port number will be assigned to you, type myport to view it.");
                    Random r = new Random();
                    PORT_NUMBER = r.nextInt(49151 - 1024) + 1024;
                }
            } catch (NumberFormatException e) {
                System.err.println("Argument" + args[0] + " must be an integer.");
                System.out.println("A random port number will be assigned to you, type myport to view it.");
                Random r = new Random();
                PORT_NUMBER = r.nextInt(49151 - 1024) + 5000;
            }
        }
        else {
            Random r = new Random();
            PORT_NUMBER = r.nextInt(49151 - 1024) + 1024;
        }

        //create an arraylist to store the names of all connections
        ConnectionLists list = new ConnectionLists ();

        //create an arraylist to store the actual objects of all connections
        ConnectionLists connections = new ConnectionLists ();

        // server is listening on port 5000-6000
        ServerSocket serverS = new ServerSocket(PORT_NUMBER);
        Server mainServer = new Server(serverS, list, connections);
        mainServer.start();


        String[] tokenAns;
        String message;

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(">");
            String temp = scanner.nextLine();
            tokenAns = temp.split(" ");

            //if they write exit then close all connections and terminate this process
            if (tokenAns[0].equalsIgnoreCase("exit")) {
                serverS.close();
                System.out.println("Connection closed");
                break;
            }

            switch (tokenAns[0].toLowerCase()) {

                case "help":
                    System.out.println("The different commands are: ");
                    System.out.print("help: Display information about "
                            + "the available user interface options or command manual.\n");
                    System.out.println("myip: Display the IP address of this process.\n");
                    System.out.println("myport: Display the port on which "
                            + "this process is listening for incoming connections.\n");
                    System.out.println("connect: <destination>  <port  no>  :  "
                            + "This command establishes a new TCP connection to the "
                            + "specified<destination> at the specified < port no>. "
                            + "The <destination> is the IP address of the computer.\n");
                    System.out.println("list: Display a numbered list of all "
                            + "the connections this process is part of.\n");
                    System.out.println("terminate:  <connection  id.>  This  "
                            + "command  will  terminate  the  connection  "
                            + "listed  under  the  specifiednumber  when  "
                            + "LIST  is  used  to  display  all  connections. \n");
                    System.out.println("send: <connection id.> <message> "
                            + "(For example, send 3 Oh! This project is a "
                            + "piece of cake). This willsend the message to "
                            + "the host on the connection that is designated "
                            + "by the number 3 when command list is used. \n");
                    System.out.println("exit: Close all connections and "
                            + "terminate this process.\n");
                    break;

                //first check if we're already connected by checking the list
                case "connect":
                    if(list.contains(tokenAns[1]+" "+tokenAns[2]+" "+PORT_NUMBER+" Host")) {
                        System.out.println("You are already connected to them!");
                    }
                    else {
                        Client newConnect = new Client(tokenAns[1], tokenAns[2], PORT_NUMBER, list);
                        newConnect.start();
                        connections.addList(newConnect);
                    }
                    break;

                case "myip":
                    // print the IP Address of your machine (inside your local network)
                    System.out.println("The IP address of this process: " +
                            InetAddress.getLocalHost().getHostAddress() + "\n");
                    break;

                case "myport":
                    System.out.println("The port number of this process: " +
                            PORT_NUMBER + "\n");
                    break;

                case "list":
                    if (connections.isEmpty()) {
                        System.out.println("You are not connected to anyone.\n");
                    } else {
                        list.printList();
                    }
                    break;

                //Check to make sure id number is valid
                case "terminate":
                    if(Integer.parseInt(tokenAns[1]) <= connections.size()) {
                        int id = Integer.parseInt(tokenAns[1])-1;
                        //remove the thread

                        //remove from the list of connections
                        list.removeList(tokenAns[id]);
                        connections.removeList(tokenAns[id]);
                        //must also remove from their list
                    }
                    else {
                        System.out.println("Error: Please select an ID number from the list.");
                    }
                    break;

                //Check to make sure id number is valid
                case "send":
                    if(Integer.parseInt(tokenAns[1]) <= connections.size()){
                        message = fuseMessage(tokenAns);
                        if(message.equalsIgnoreCase("Too Long")) {
                            System.out.println("This message is too long, make sure it is 100 or less characters.");
                        }
                        //check if its the connected peer is host or client
                        else {
                            int id = Integer.parseInt(tokenAns[1])-1;
                            if(list.isClient(id)) {
                                ((Handler)connections.get(id)).sendMessage(message, id);
                            }
                            else {
                                ((Client)connections.get(id)).sendMessage(message, id);
                            }
                        }
                    }
                    else {
                        System.out.println("Error: Please select an ID number from the list.");
                    }
                    break;

                default:
                    System.out.println("Invalid input\n");
                    break;
            }
        }
        try {
            serverS.close();
        } catch (Exception f) {
            f.printStackTrace();
        }

    }

    //make the message into one string and make sure its less than 100 char
    public static String fuseMessage(String[] message) {
        String temp="";
        StringBuilder sb = new StringBuilder();
        for(int i = 2; i<message.length; i++) {
            sb.append(message[i]);
            sb.append(" ");
        }
        temp = sb.toString();
        if(lessThanHunned(temp)) {
            return temp;
        }
        return "Too Long";
    }

    public static boolean lessThanHunned(String temp) {
        if(temp.length() <= 100){
            return true;
        }
        return false;
    }
}

