package chat.subclass;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client extends Thread{
    final String ip;
    final int port;
    final int myPortNumber;
    final String ipPort;
    private ConnectionLists list;
    private DataInputStream dis;
    private DataOutputStream dos;

    public Client(String ip, String port, int myPortNumber, ConnectionLists list){
        this.ip = ip;
        this.port = Integer.parseInt(port);
        this.myPortNumber = myPortNumber;
        this.list = list;
        ipPort = ip +" "+port;
    }

    @Override
    public void run() {
        try
        {
            //Scanner scn = new Scanner(System.in);
            String tosend = "";
            String received="";
            String[] tokenAns;
            // establish the connection with server port
            Socket s = new Socket(ip, port);
            list.addList(ip+" "+port+" Host");

            // obtaining input and out streams
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());

            //send the server your ip and port in case they want to connect to you
            boolean sendIP = false;
            // the following loop performs the exchange of
            // information between client and client handler
            while (true)
            {
                received = dis.readUTF();
                tokenAns = received.split(" ");


                //received = dis.readUTF();
                if(!sendIP) {
                    dos.writeUTF(InetAddress.getLocalHost().getHostAddress()+" "+myPortNumber);
                    System.out.println(received);
                    sendIP = true;
                }
                else {
                    switch(tokenAns[0]) {
                        case "send": //they sent a message so display their ip, port and message
                            System.out.println("Message received from: "+ip);
                            System.out.println("Sender's Port: "+port);
                            for(int i=1; i < tokenAns.length; i++) {
                                System.out.print(tokenAns[i]+" ");
                            }
                            System.out.println();
                            break;
                    }
                    // If client sends exit,close this connection
                    // and then break from the while loop
                    if (tosend.equals("Exit")) {
                        System.out.println("Closing this connection : " + s);
                        s.close();
                        System.out.println("Connection closed");
                        break;
                    }
                }
            }

            // closing resources
            //scn.close();
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void sendMessage(String message, int id) {
        try {
            //dos.writeUTF("send "+InetAddress.getLocalHost().getHostAddress()+" "+myPortNumber+" "+message);
            dos.writeUTF("send "+message);
            System.out.println("Message sent to: ID# "+ ++id);
        } catch (IOException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void closeConnection(Socket s) throws IOException{
        System.out.println("Closing this connection : " + s);
        s.close();
        System.out.println("Connection closed");
    }
}
