package chat.subclass;

import java.util.ArrayList;

public class ConnectionLists {
    private static ArrayList<String> iPAddress = new ArrayList<>();

    private static ArrayList<Object> connections = new ArrayList<>();
    //creates the array list
    public ConnectionLists() {

    }

    public void addList(String newClient) {
        iPAddress.add(newClient);
    }

    public void addList(Client newConnect) {
        connections.add(newConnect);
    }

    public void addList(Handler newConnect) {
        connections.add(newConnect);
    }

    public int size() {
        return connections.size();
    }

    public Object get(int index) {
        return connections.get(index);
    }

    public boolean isClient(int index) {
        String[] client = iPAddress.get(index).split(" ");
        if(client[2].equalsIgnoreCase("Client")) {
            return true;
        }
        return false;
    }

    //removing by id in arraylist however the number is a string and
    //it is also 1 higher so we must parse to int and reduce by 1
    public void removeList(String idString) {
        int idNumber;
        idNumber = Integer.parseInt(idString);
        idNumber--;

        iPAddress.remove(idNumber);
    }


    public boolean isEmpty() {
        if(iPAddress.isEmpty() && connections.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean contains(String entry) {
        return iPAddress.contains(entry);
    }

    public void printList() {
        System.out.println("ID:     IP              AddressPort No.         "
                + "They Are The");
        for(int i=0; i<iPAddress.size() ;i++){
            int count = i+1;
            if(i<8) {
                System.out.print(" "+count+":     ");
            }
            else System.out.print(count+":     ");

            String[] ipPort = iPAddress.get(i).split(" ");
            System.out.println(ipPort[0]+"             "+ipPort[1]+"        "
                    + "     "+ipPort[2]);
        }
        System.out.println();
        printConnections();
    }

    public void printConnections() {
        System.out.println("Connections list:");
        for(int i=0; i<connections.size() ;i++){
            System.out.println(connections.get(i));
        }
    }
}
