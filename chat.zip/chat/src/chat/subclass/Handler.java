package chat.subclass;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Handler extends Thread{
    final DataInputStream dis;
    final DataOutputStream dos;
    final Socket s;
    private ConnectionLists list;
    private String theirIPPort;
    //private ListOfComps connections;

    // Constructor
    public Handler(Socket s, DataInputStream dis, DataOutputStream dos, ConnectionLists list)
    {
        this.s = s;
        this.dis = dis;
        this.dos = dos;
        this.list = list;
        //this.connections = connections;
    }

    @Override
    public void run()  {
        String received;
        String[] tokenAns;

        //Display a message to show the client successful connection
        //has been made
        try {
            dos.writeUTF("Successfully connected!");
        } catch (IOException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
        //have client send ip so we can display in our list of connections
        boolean receivedIP = false;

        while (true)
        {
            try {
                // receive the answer from client
                received = dis.readUTF();
                tokenAns = received.split(" ");

                //only receive IP and port number once, it'll be the first thing they automatically send
                if(!receivedIP) {

                    System.out.println("Their ip is "+tokenAns[0]+
                            " and their port no. is "+tokenAns[1]);
                    theirIPPort = tokenAns[0] +" "+ tokenAns[1];
                    list.addList(theirIPPort+" Client");
                    receivedIP = true;
                }
                else {
                    switch(tokenAns[0]) {
                        case "send": //they sent a message so display their ip, port and message
                           /* System.out.println("Message received from: "+tokenAns[1]);
                            System.out.println("Sender's Port: "+tokenAns[2]);
                            for(int i=3; i < tokenAns.length; i++) {
                                System.out.print(tokenAns[i]+" ");
                            }
                            System.out.println();*/
                            String[] temp = theirIPPort.split(" ");
                            System.out.println("Message received from: "+temp[0]);
                            System.out.println("Sender's Port: "+temp[1]);
                            System.out.println("Message: "+tokenAns[1]);
                            break;
                    }
                    /*System.out.println("Message received from: "+s);
                    System.out.println(received);*/
                    if (received.equalsIgnoreCase("Exit")) {
                        //System.out.println("Client " + this.s + " sends exit...");
                        System.out.println("Closing" + this.s + "connection.");
                        this.s.close();

                        System.out.println("Connection closed");
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try{
            // closing resources
            this.dis.close();
            this.dos.close();

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void sendMessage(String message, int id) {
        try {
            dos.writeUTF("send "+message);
            System.out.println("Message sent to: ID# "+ ++id);
        } catch (IOException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
